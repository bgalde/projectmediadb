package edu.umuc.cmsc495;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheMovieDbRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheMovieDbRestApiApplication.class, args);
	}
}
